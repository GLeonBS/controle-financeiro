create function char_length_mascara(mascara character varying, posicao integer) returns integer
    language plpgsql
as
$$
            DECLARE
            retorno_length integer;
            BEGIN
            RAISE INFO 'Mascara %, posicao %',mascara , posicao;
            SELECT CHAR_LENGTH(ARRAY_TO_STRING((REGEXP_SPLIT_TO_ARRAY(mascara, E'\\.'))[1: posicao], '')) INTO
            retorno_length;
            return retorno_length;
            END;
            $$;

alter function char_length_mascara(varchar, integer) owner to oxyorc;

