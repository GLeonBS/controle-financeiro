create view lote_receita_diferenca_banco
            (id, numero_realizacao, lote_tributos, data, soma_evento_lancado, soma_receita, diferenca) as
SELECT y.id,
       y.numero_realizacao,
       y.lote_tributos,
       y.data,
       y.soma_evento_lancado,
       y.soma_receita,
       y.soma_receita - y.soma_evento_lancado AS diferenca
FROM (SELECT rr2.id,
             rr2.numero_realizacao,
             itl.numero         AS lote_tributos,
             rr2.data,
             abs(x.soma_evento) AS soma_evento_lancado,
             abs(sum(
                     CASE
                         WHEN r.id_tipo_operacao > 1::numeric THEN rrf.valor * '-1'::integer::numeric
                         ELSE rrf.valor
                         END))  AS soma_receita
      FROM (SELECT rr.id,
                   pc.codigo,
                   sum(
                           CASE
                               WHEN elc.sinal::text = 'C'::text THEN elc.valor * '-1'::integer::numeric
                               ELSE elc.valor
                               END) AS soma_evento
            FROM oxyctb.realizacao_receita rr
                     LEFT JOIN oxyctb.evento_lancamento_conta elc ON elc.id_evento_lancamento = rr.id_evento_lancamento
                     JOIN oxyctb.plano_contas pc
                          ON elc.id_plano = pc.id AND pc.id_exercicio = rr.id_exercicio AND pc.codigo::text ~~ '111%'::text
            WHERE rr.id_exercicio = ((SELECT e.id
                                      FROM oxyctb.exercicio e
                                      WHERE e.exercicio = 2022::numeric
                                        AND e.entidade = 1::numeric))
            GROUP BY rr.id, pc.codigo) x
               JOIN oxyctb.realizacao_receita rr2 ON x.id = rr2.id
               JOIN oxyctb.realizacao_receita_item rri2 ON rr2.id = rri2.id_realizacao_receita
               LEFT JOIN oxyctb.realizacao_receita_fonte rrf ON rrf.id_receita_item = rri2.id
               LEFT JOIN oxyctb.receita r ON rri2.id_receita = r.id
               LEFT JOIN oxyctb.integracao_tributos_lote itl ON itl.id_realizacao_receita = rr2.id
      GROUP BY rr2.id, rr2.numero_realizacao, itl.numero, rr2.data, (abs(x.soma_evento))
      HAVING abs(x.soma_evento) <> abs(sum(
              CASE
                  WHEN r.id_tipo_operacao > 1::numeric THEN rrf.valor * '-1'::integer::numeric
                  ELSE rrf.valor
                  END))) y
ORDER BY y.numero_realizacao;

alter table lote_receita_diferenca_banco
    owner to elotech;

