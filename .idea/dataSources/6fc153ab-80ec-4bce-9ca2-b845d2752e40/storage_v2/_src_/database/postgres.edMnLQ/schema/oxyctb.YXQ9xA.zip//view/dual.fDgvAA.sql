create view dual(id) as
SELECT 'X'::character varying AS id;

alter table dual
    owner to oxyctb;

