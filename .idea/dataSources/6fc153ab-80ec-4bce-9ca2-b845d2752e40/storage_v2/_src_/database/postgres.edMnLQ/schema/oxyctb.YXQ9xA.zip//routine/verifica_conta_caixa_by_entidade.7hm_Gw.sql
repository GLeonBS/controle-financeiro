create function verifica_conta_caixa_by_entidade(entidade_param numeric, tipo_conta_bancaria_param numeric) returns boolean
    language plpgsql
as
$$
            BEGIN
            IF tipo_conta_bancaria_param = 3 THEN
            RETURN NOT EXISTS (SELECT 1 FROM conta_bancaria cb WHERE cb.id_entidade = entidade_param AND cb.tipo_conta_bancaria = 3) AND tipo_conta_bancaria_param = 3;
            ELSE
            RETURN TRUE;
            END IF;
            END;
            $$;

alter function verifica_conta_caixa_by_entidade(numeric, numeric) owner to oxyctb;

