create view empenho_adiantamento_portal
            (codigo_prestacao, exercicio, entidade, nome, data_prestacao, empenho_numero, exercicio_empenho,
             data_empenho, valor_empenho, cargo, tipo_retorno, tipo_solicitacao, total_documentos, valor, data_inicio,
             data_fim, lotacao, valor_restituido)
as
SELECT diaria_reembolso.codigo_prestacao,
       diaria_reembolso.exercicio,
       diaria_reembolso.entidade,
       diaria_reembolso.funcionario                               AS nome,
       diaria_reembolso.data_prestacao,
       diaria_reembolso.empenho_numero,
       diaria_reembolso.exercicio_empenho,
       diaria_reembolso.data_empenho,
       diaria_reembolso.valor_empenho,
       diaria_reembolso.cargo,
       diaria_reembolso.tipo_retorno,
       diaria_reembolso.tipo_solicitacao,
       diaria_reembolso.total_documentos,
       diaria_reembolso.valor,
       diaria_reembolso.data_inicio,
       diaria_reembolso.data_fim,
       ''::text                                                   AS lotacao,
       diaria_reembolso.valor - diaria_reembolso.total_documentos AS valor_restituido
FROM (SELECT e.numero_empenho          AS codigo_prestacao,
             e2.exercicio,
             e2.entidade,
             p.nome                    AS funcionario,
             e.data                    AS data_prestacao,
             e.numero_empenho          AS empenho_numero,
             e2.exercicio              AS exercicio_empenho,
             e.data                    AS data_empenho,
             e.valor                   AS valor_empenho,
             p.cargo,
             'EMPENHO_REEMBOLSO'::text AS tipo_retorno,
             0                         AS tipo_solicitacao,
             e.valor,
             e.data                    AS data_inicio,
             e.data                    AS data_fim,
             0                         AS total_documentos
      FROM oxyctb.empenho e
               JOIN oxyctb.exercicio e2 ON e2.id = e.id_exercicio
               JOIN oxyctb.pessoa p ON p.id = e.id_credor
      WHERE e.is_reembolso::text = 'S'::text
      UNION ALL
      SELECT dm.numero_solicitacao                AS codigo_prestacao,
             e3.exercicio,
             e3.entidade,
             p.nome                               AS funcionario,
             dm.data_prestacao_contas             AS data_prestacao,
             e.numero_empenho                     AS empenho_numero,
             e2.exercicio                         AS exercicio_empenho,
             e.data                               AS data_empenho,
             e.valor                              AS valor_empenho,
             p.cargo,
             'ADIANTAMENTO'::text                 AS tipo_retorno,
             dm.tipo_solicitacao,
             dm.valor_adiantamento                AS valor,
             dm.data_inicio,
             dm.data_final                        AS data_fim,
             COALESCE(sum(dmd.valor), 0::numeric) AS total_documentos
      FROM oxyctb.diaria_movimentacao dm
               JOIN oxyctb.empenho e ON dm.id = e.id_diaria
               JOIN oxyctb.exercicio e2 ON e2.id = e.id_exercicio
               JOIN oxyctb.exercicio e3 ON e3.id = dm.id_exercicio
               JOIN oxyctb.pessoa p ON p.id = dm.id_servidor
               LEFT JOIN oxyctb.diaria_movimentacao_documento dmd ON dmd.id_diaria_movimentacao = dm.id
      WHERE dm.tipo_solicitacao = 2::numeric
        AND dm.prestacao_finalizada::text = 'S'::text
      GROUP BY dm.numero_solicitacao, e3.exercicio, e3.entidade, p.nome, dm.data_prestacao_contas, e.numero_empenho,
               e2.exercicio, e.data, e.valor, p.cargo, 'ADIANTAMENTO'::text, dm.tipo_solicitacao, dm.valor_adiantamento,
               dm.data_inicio, dm.data_final) diaria_reembolso;

alter table empenho_adiantamento_portal
    owner to oxyctb;

