create function realizacaoreceita_fonte_check(id_realizacao_receita_item numeric, id_fonte_recurso numeric) returns boolean
    language plpgsql
as
$$
declare
    countValue numeric;
begin 

    raise info 'id_fonte %, id_realizacao_receita_item %', id_fonte_recurso, id_realizacao_receita_item; 

select count(*) into countValue
    from oxyctb.receita_fonte  rf
    where rf.id_fonte = id_fonte_recurso and rf.id_receita in (
        select ri.id_receita from oxyctb.realizacao_receita_item ri where ri.id = id_realizacao_receita_item
    );

  return countValue > 0;
end;
$$;

alter function realizacaoreceita_fonte_check(numeric, numeric) owner to oxyctb;

