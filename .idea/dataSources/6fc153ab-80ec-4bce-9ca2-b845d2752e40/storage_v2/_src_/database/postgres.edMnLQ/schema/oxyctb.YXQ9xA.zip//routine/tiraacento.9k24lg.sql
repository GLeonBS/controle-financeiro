create function tiraacento(pstring character varying) returns character varying
    language plpgsql
as
$$
            DECLARE
            vStringReturn varchar(4000);
            begin
            vStringReturn := translate( pString,
            'ÁÇÉÍÓÚÀÈÌÒÙÂÊÎÔÛÃÕËÜáçéíóúàèìòùâêîôûãõëü',
            'ACEIOUAEIOUAEIOUAOEUaceiouaeiouaeiouaoeu');
            return vStringReturn;
            end;
            $$;

alter function tiraacento(varchar) owner to oxyctb;

